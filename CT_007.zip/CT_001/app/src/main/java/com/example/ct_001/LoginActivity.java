package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private ImageView passwordToggle;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // 로그인 화면 표시

        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        passwordToggle = findViewById(R.id.password_toggle);
        loginButton = findViewById(R.id.login_button);

        // 비밀번호 표시/숨김 토글
        passwordToggle.setOnClickListener(v -> {
            if (passwordInput.getInputType() == (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)) {
                passwordInput.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                passwordToggle.setImageResource(android.R.drawable.ic_menu_view); // 임시 아이콘 사용
            } else {
                passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                passwordToggle.setImageResource(android.R.drawable.ic_menu_close_clear_cancel); // 임시 아이콘 사용
            }
            passwordInput.setSelection(passwordInput.getText().length()); // 커서 위치 유지
        });

        // 로그인 버튼 클릭 이벤트
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "모든 필드를 입력하세요.", Toast.LENGTH_SHORT).show();
            } else {
                if (username.equals("admin") && password.equals("1234")) {
                    Toast.makeText(this, "로그인 성공!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(this, MainActivity.class); // 로그인 성공 시 MainActivity로 이동
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "로그인 실패: 잘못된 아이디 또는 비밀번호", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
