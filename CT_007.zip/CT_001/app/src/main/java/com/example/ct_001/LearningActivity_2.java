package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class LearningActivity_2 extends AppCompatActivity {

    private TextView resultTextView;
    private TextView targetTextView;
    private Button startButton;
    private SpeechRecognizer speechRecognizer;
    private String targetText = "안녕하세요";

    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_2); // 학습 화면 레이아웃 연결

        // Firestore 초기화
        firestore = FirebaseFirestore.getInstance();

        // 학습 관련 View 초기화
        resultTextView = findViewById(R.id.result_text);
        targetTextView = findViewById(R.id.target_text);
        startButton = findViewById(R.id.start_button);

        targetTextView.setText(targetText);

        initializeSpeechRecognizer();

        startButton.setOnClickListener(v -> startSpeechRecognition());

        // 하단 네비게이션 버튼 설정
        setupNavigationButtons();
    }

    private void setupNavigationButtons() {
        Button learnButton = findViewById(R.id.learnButton);
        Button reviewButton = findViewById(R.id.reviewButton);
        Button performanceButton = findViewById(R.id.performanceButton);

        // 학습 버튼 클릭 이벤트
        learnButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_2.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });

        // 복습 버튼 클릭 이벤트
        reviewButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_2.this, ReviewActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });

        // 성취도 버튼 클릭 이벤트
        performanceButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_2.this, ProgressActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });
    }

    private void initializeSpeechRecognizer() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                Toast.makeText(LearningActivity_2.this, "음성을 입력하세요...", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String resultText = matches.get(0);
                    resultTextView.setText(resultText);
                    compareResults(resultText);
                } else {
                    resultTextView.setText("음성 인식 결과 없음");
                }
            }

            @Override
            public void onError(int error) {
                Toast.makeText(LearningActivity_2.this, "음성 인식 오류: " + error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onBeginningOfSpeech() {}
            @Override
            public void onRmsChanged(float rmsdB) {}
            @Override
            public void onBufferReceived(byte[] buffer) {}
            @Override
            public void onEndOfSpeech() {}
            @Override
            public void onPartialResults(Bundle partialResults) {}
            @Override
            public void onEvent(int eventType, Bundle params) {}
        });
    }

    private void startSpeechRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        speechRecognizer.startListening(intent);
    }

    private void compareResults(String resultText) {
        int similarity = calculateSimilarity(targetText, resultText);
        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        saveLearningData("user123", currentDate, similarity);
        Toast.makeText(this, "일치율: " + similarity + "%", Toast.LENGTH_LONG).show();
    }

    private int calculateSimilarity(String target, String input) {
        int editDistance = calculateEditDistance(target, input);
        int maxLength = Math.max(target.length(), input.length());
        return (int) ((1 - (double) editDistance / maxLength) * 100);
    }

    private int calculateEditDistance(String str1, String str2) {
        int[][] dp = new int[str1.length() + 1][str2.length() + 1];
        for (int i = 0; i <= str1.length(); i++) {
            for (int j = 0; j <= str2.length(); j++) {
                if (i == 0) dp[i][j] = j;
                else if (j == 0) dp[i][j] = i;
                else if (str1.charAt(i - 1) == str2.charAt(j - 1)) dp[i][j] = dp[i - 1][j - 1];
                else dp[i][j] = 1 + Math.min(dp[i - 1][j - 1], Math.min(dp[i - 1][j], dp[i][j - 1]));
            }
        }
        return dp[str1.length()][str2.length()];
    }

    private void saveLearningData(String userId, String timestamp, int accuracy) {
        Map<String, Object> learningData = new HashMap<>();
        learningData.put("timestamp", timestamp);
        learningData.put("accuracy", accuracy);

        firestore.collection("users")
                .document(userId)
                .collection("learning_data")
                .add(learningData)
                .addOnSuccessListener(documentReference ->
                        Toast.makeText(this, "데이터 저장 성공", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(this, "데이터 저장 실패", Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
