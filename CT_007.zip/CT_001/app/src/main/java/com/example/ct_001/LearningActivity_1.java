package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LearningActivity_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_1); // 첫 번째 학습 레이아웃 연결

        // 하단 네비게이션 버튼 설정
        setupNavigationButtons();

        // 정답 버튼 클릭 이벤트 설정
        setupAnswerButtons();
    }

    private void setupNavigationButtons() {
        Button learnButton = findViewById(R.id.learnButton);
        Button reviewButton = findViewById(R.id.reviewButton);
        Button performanceButton = findViewById(R.id.performanceButton);

        // 학습 버튼 클릭 이벤트
        learnButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_1.this, MainActivity.class); // MainActivity로 이동
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });

        // 복습 버튼 클릭 이벤트
        reviewButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_1.this, ReviewActivity.class); // ReviewActivity로 이동
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });

        // 성취도 버튼 클릭 이벤트
        performanceButton.setOnClickListener(v -> {
            Intent intent = new Intent(LearningActivity_1.this, ProgressActivity.class); // ProgressActivity로 이동
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        });
    }

    private void setupAnswerButtons() {
        // 정답 버튼 초기화
        Button choiceButton1 = findViewById(R.id.choiceButton1);
        Button choiceButton2 = findViewById(R.id.choiceButton2);
        Button choiceButton3 = findViewById(R.id.choiceButton3);

        // 클릭 이벤트 리스너 설정
        Button.OnClickListener listener = v -> {
            Intent intent = new Intent(LearningActivity_1.this, LearningActivity_2.class); // activity_learning_2로 이동
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish();
        };

        // 버튼에 리스너 설정
        choiceButton1.setOnClickListener(listener);
        choiceButton2.setOnClickListener(listener);
        choiceButton3.setOnClickListener(listener);
    }
}
