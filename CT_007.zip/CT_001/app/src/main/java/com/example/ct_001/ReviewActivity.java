package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ReviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        // 복습 시작 버튼
        Button startReviewButton = findViewById(R.id.startReviewButton);

        // 클릭 이벤트 설정
        startReviewButton.setOnClickListener(v -> {
            // activity_game 화면으로 이동
            Intent intent = new Intent(ReviewActivity.this, GameActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 화면 전환 애니메이션
        });

        // 결과 초기화 버튼
        Button clearResultsButton = findViewById(R.id.clearResultsButton);

        // 결과 초기화 클릭 이벤트 (예시)
        clearResultsButton.setOnClickListener(v -> {
            // 초기화 로직 추가 (필요 시)
        });
    }
}
