package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private String selectedKeyword = null; // 선택된 키워드 저장

    // 드롭다운 관련 변수
    private LinearLayout mySubcategories, lifeSubcategories, foodSubcategories, workSubcategories, financeSubcategories;
    private ImageView myDropdown, lifeDropdown, foodDropdown, workDropdown, financeDropdown;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 네비게이션 버튼 설정
        Button learnButton = findViewById(R.id.learnButton);
        Button reviewButton = findViewById(R.id.reviewButton);
        Button performanceButton = findViewById(R.id.performanceButton);

        // 학습 버튼 클릭 이벤트 (현재 화면이므로 새로 시작하지 않음)
        learnButton.setOnClickListener(v -> {
            Toast.makeText(this, "현재 화면입니다.", Toast.LENGTH_SHORT).show();
        });

        // 복습 버튼 클릭 이벤트
        reviewButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ReviewActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish(); // 현재 Activity 종료 (옵션)
        });

        // 성취도 버튼 클릭 이벤트
        performanceButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ProgressActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish(); // 현재 Activity 종료 (옵션)
        });

        // 드롭다운 메뉴 설정
        setupDropdownMenus();

        // 키워드 버튼 클릭 이벤트 처리
        setupKeywordSelection();

        // 학습하기 버튼 이벤트 처리
        Button startLearningButton = findViewById(R.id.startLearningButton);
        startLearningButton.setOnClickListener(v -> {
            if (selectedKeyword == null) {
                Toast.makeText(MainActivity.this, "키워드를 선택하세요!", Toast.LENGTH_SHORT).show();
            } else {
                // activity_learning_1로 이동하도록 수정
                Intent intent = new Intent(MainActivity.this, LearningActivity_1.class);
                intent.putExtra("keyword", selectedKeyword); // 선택된 키워드 전달
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }

    private void setupDropdownMenus() {
        // XML에서 View 가져오기
        mySubcategories = findViewById(R.id.mySubcategories);
        lifeSubcategories = findViewById(R.id.lifeSubcategories);
        foodSubcategories = findViewById(R.id.foodSubcategories);
        workSubcategories = findViewById(R.id.workSubcategories);
        financeSubcategories = findViewById(R.id.financeSubcategories);

        myDropdown = findViewById(R.id.myDropdown);
        lifeDropdown = findViewById(R.id.lifeDropdown);
        foodDropdown = findViewById(R.id.foodDropdown);
        workDropdown = findViewById(R.id.workDropdown);
        financeDropdown = findViewById(R.id.financeDropdown);

        // MY 카테고리 클릭 이벤트
        myDropdown.setOnClickListener(v -> toggleVisibility(mySubcategories));

        // 생활 / 소비 카테고리 클릭 이벤트
        lifeDropdown.setOnClickListener(v -> toggleVisibility(lifeSubcategories));

        // 음식 / 요리 카테고리 클릭 이벤트
        foodDropdown.setOnClickListener(v -> toggleVisibility(foodSubcategories));

        // 업무 카테고리 클릭 이벤트
        workDropdown.setOnClickListener(v -> toggleVisibility(workSubcategories));

        // 재정 / 금융 카테고리 클릭 이벤트
        financeDropdown.setOnClickListener(v -> toggleVisibility(financeSubcategories));
    }

    private void setupKeywordSelection() {
        // 키워드 버튼 클릭 이벤트 설정 (예시: 각 카테고리에서 버튼 처리)
        setKeywordSelection(mySubcategories, "MY");
        setKeywordSelection(lifeSubcategories, "생활 / 소비");
        setKeywordSelection(foodSubcategories, "음식 / 요리");
        setKeywordSelection(workSubcategories, "업무");
        setKeywordSelection(financeSubcategories, "재정 / 금융");
    }

    private void setKeywordSelection(LinearLayout categoryLayout, String category) {
        for (int i = 0; i < categoryLayout.getChildCount(); i++) {
            View child = categoryLayout.getChildAt(i);
            if (child instanceof Button) {
                child.setOnClickListener(v -> {
                    Button button = (Button) v;
                    selectedKeyword = button.getText().toString(); // 선택된 키워드 저장
                    Toast.makeText(this, category + ": " + selectedKeyword + " 선택됨", Toast.LENGTH_SHORT).show();
                });
            }
        }
    }

    private void toggleVisibility(LinearLayout subcategories) {
        if (subcategories.getVisibility() == View.VISIBLE) {
            subcategories.setVisibility(View.GONE);
            Toast.makeText(this, "항목 숨김", Toast.LENGTH_SHORT).show(); // 테스트용 메시지
        } else {
            subcategories.setVisibility(View.VISIBLE);
            Toast.makeText(this, "항목 표시", Toast.LENGTH_SHORT).show(); // 테스트용 메시지
        }
    }
}
