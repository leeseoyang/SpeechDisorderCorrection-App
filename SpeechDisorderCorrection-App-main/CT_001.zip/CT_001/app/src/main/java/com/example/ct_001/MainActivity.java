package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView resultTextView;
    private TextView targetTextView;
    private Button startButton;
    private SpeechRecognizer speechRecognizer;
    private String targetText = "안녕하세요";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.result_text);
        targetTextView = findViewById(R.id.target_text);
        startButton = findViewById(R.id.start_button);

        targetTextView.setText(targetText);

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                Toast.makeText(MainActivity.this, "음성을 입력하세요...", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String resultText = matches.get(0);
                    resultTextView.setText(resultText);
                    compareResults(resultText);
                } else {
                    resultTextView.setText("음성 인식 결과 없음");
                }
            }

            @Override
            public void onError(int error) {
                Toast.makeText(MainActivity.this, "음성 인식 오류: " + error, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onBeginningOfSpeech() {}
            @Override
            public void onRmsChanged(float rmsdB) {}
            @Override
            public void onBufferReceived(byte[] buffer) {}
            @Override
            public void onEndOfSpeech() {}
            @Override
            public void onPartialResults(Bundle partialResults) {}
            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        startButton.setOnClickListener(v -> startSpeechRecognition());
    }

    private void startSpeechRecognition() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        speechRecognizer.startListening(intent);
    }

    private int calculateSimilarity(String target, String input) {
        String[] targetWords = target.split(" ");
        String[] inputWords = input.split(" ");
        int matchCount = 0;
        for (int i = 0; i < Math.min(targetWords.length, inputWords.length); i++) {
            if (targetWords[i].equalsIgnoreCase(inputWords[i])) {
                matchCount++;
            }
        }
        return (int) ((double) matchCount / targetWords.length * 100);
    }

    private void compareResults(String resultText) {
        int similarity = calculateSimilarity(targetText, resultText);
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        saveLearningData("user123", currentDate, similarity);
        Toast.makeText(this, "일치율: " + similarity + "%", Toast.LENGTH_LONG).show();
    }

    private void saveLearningData(String userId, String date, int accuracy) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference userRef = database.getReference("users").child(userId);
        userRef.child("date").setValue(date);
        userRef.child("accuracy").setValue(accuracy);
    }
}
