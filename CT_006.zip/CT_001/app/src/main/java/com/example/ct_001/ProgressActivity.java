package com.example.ct_001;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProgressActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress); // 성취도 화면 레이아웃 연결

        // 네비게이션 버튼 설정
        Button learnButton = findViewById(R.id.learnButton);
        Button reviewButton = findViewById(R.id.reviewButton);
        Button performanceButton = findViewById(R.id.performanceButton);

        // 학습 버튼 클릭 이벤트
        learnButton.setOnClickListener(v -> {
            Intent intent = new Intent(ProgressActivity.this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish(); // 현재 Activity 종료 (옵션)
        });

        // 복습 버튼 클릭 이벤트
        reviewButton.setOnClickListener(v -> {
            Intent intent = new Intent(ProgressActivity.this, ReviewActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out); // 페이드 인/아웃 효과
            finish(); // 현재 Activity 종료 (옵션)
        });

        // 성취도 버튼 클릭 이벤트 (현재 화면이므로 새로 시작하지 않음)
        performanceButton.setOnClickListener(v -> {
            Toast.makeText(this, "현재 화면입니다.", Toast.LENGTH_SHORT).show();
        });
    }
}
