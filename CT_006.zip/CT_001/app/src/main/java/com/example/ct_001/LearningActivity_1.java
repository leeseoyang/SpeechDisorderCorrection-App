package com.example.ct_001;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class LearningActivity_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_1); // 두 번째 레이아웃
    }
}
